﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gestion_commercial
{
    public partial class FrmProduit : Form
    {
        public FrmProduit()
        {
            InitializeComponent();
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {

        }

        private void dtgvUtilisateurs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
